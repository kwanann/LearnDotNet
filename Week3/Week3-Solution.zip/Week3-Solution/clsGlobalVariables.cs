﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3_Solution
{
    public static class clsGlobalVariables
    {
        public static frmLogin LoginForm { get; set; }
        public static clsLoggedInUser LoggedInUser { get; set; }
        public static readonly bool isDebug = true;
    }

    public class clsLoggedInUser
    {
        public int BusinessEntityID { get; set; }
        public bool IsManager { get; set; }
        public string GroupName { get; set; }
        public string Department { get; set; }
        public short? OrganizationLevel { get; set; }
    }
}
