﻿namespace Week3_Solution
{
    partial class frmHR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbEmployeeList = new System.Windows.Forms.GroupBox();
            this.DGV = new System.Windows.Forms.DataGridView();
            this.DGV_Title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGV_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGV_JobTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGV_EmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGV_City = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGV_State = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGV_BusinessEntityID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PanelActions = new System.Windows.Forms.Panel();
            this.PanelFillterTop = new System.Windows.Forms.Panel();
            this.PanelActionButtons = new System.Windows.Forms.Panel();
            this.btnViewCurrentStaff = new System.Windows.Forms.Button();
            this.btnDebug = new System.Windows.Forms.Button();
            this.btnViewExitedStaff = new System.Windows.Forms.Button();
            this.btnAddNewStaff = new System.Windows.Forms.Button();
            this.btnManageStaff = new System.Windows.Forms.Button();
            this.btnViewStaff = new System.Windows.Forms.Button();
            this.gbEmployeeList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).BeginInit();
            this.PanelActions.SuspendLayout();
            this.PanelActionButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbEmployeeList
            // 
            this.gbEmployeeList.Controls.Add(this.DGV);
            this.gbEmployeeList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbEmployeeList.Location = new System.Drawing.Point(0, 0);
            this.gbEmployeeList.Name = "gbEmployeeList";
            this.gbEmployeeList.Size = new System.Drawing.Size(800, 356);
            this.gbEmployeeList.TabIndex = 0;
            this.gbEmployeeList.TabStop = false;
            this.gbEmployeeList.Text = "Enployee List";
            // 
            // DGV
            // 
            this.DGV.AllowUserToAddRows = false;
            this.DGV.AllowUserToDeleteRows = false;
            this.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DGV_Title,
            this.DGV_Name,
            this.DGV_JobTitle,
            this.DGV_EmailAddress,
            this.DGV_City,
            this.DGV_State,
            this.DGV_BusinessEntityID});
            this.DGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGV.Location = new System.Drawing.Point(3, 16);
            this.DGV.MultiSelect = false;
            this.DGV.Name = "DGV";
            this.DGV.ReadOnly = true;
            this.DGV.Size = new System.Drawing.Size(794, 337);
            this.DGV.TabIndex = 0;
            // 
            // DGV_Title
            // 
            this.DGV_Title.DataPropertyName = "Title";
            this.DGV_Title.HeaderText = "Title";
            this.DGV_Title.Name = "DGV_Title";
            this.DGV_Title.ReadOnly = true;
            // 
            // DGV_Name
            // 
            this.DGV_Name.DataPropertyName = "Name";
            this.DGV_Name.HeaderText = "Name";
            this.DGV_Name.Name = "DGV_Name";
            this.DGV_Name.ReadOnly = true;
            // 
            // DGV_JobTitle
            // 
            this.DGV_JobTitle.DataPropertyName = "JobTitle";
            this.DGV_JobTitle.HeaderText = "Job Title";
            this.DGV_JobTitle.Name = "DGV_JobTitle";
            this.DGV_JobTitle.ReadOnly = true;
            // 
            // DGV_EmailAddress
            // 
            this.DGV_EmailAddress.DataPropertyName = "EmailAddress";
            this.DGV_EmailAddress.HeaderText = "Email Address";
            this.DGV_EmailAddress.Name = "DGV_EmailAddress";
            this.DGV_EmailAddress.ReadOnly = true;
            // 
            // DGV_City
            // 
            this.DGV_City.DataPropertyName = "City";
            this.DGV_City.HeaderText = "City";
            this.DGV_City.Name = "DGV_City";
            this.DGV_City.ReadOnly = true;
            // 
            // DGV_State
            // 
            this.DGV_State.DataPropertyName = "State";
            this.DGV_State.HeaderText = "State";
            this.DGV_State.Name = "DGV_State";
            this.DGV_State.ReadOnly = true;
            // 
            // DGV_BusinessEntityID
            // 
            this.DGV_BusinessEntityID.DataPropertyName = "BusinessEntityID";
            this.DGV_BusinessEntityID.HeaderText = "BusinessEntityID";
            this.DGV_BusinessEntityID.Name = "DGV_BusinessEntityID";
            this.DGV_BusinessEntityID.ReadOnly = true;
            this.DGV_BusinessEntityID.Visible = false;
            // 
            // PanelActions
            // 
            this.PanelActions.Controls.Add(this.PanelActionButtons);
            this.PanelActions.Controls.Add(this.PanelFillterTop);
            this.PanelActions.Controls.Add(this.btnDebug);
            this.PanelActions.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.PanelActions.Location = new System.Drawing.Point(0, 356);
            this.PanelActions.Name = "PanelActions";
            this.PanelActions.Size = new System.Drawing.Size(800, 94);
            this.PanelActions.TabIndex = 1;
            // 
            // PanelFillterTop
            // 
            this.PanelFillterTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelFillterTop.Location = new System.Drawing.Point(0, 0);
            this.PanelFillterTop.Name = "PanelFillterTop";
            this.PanelFillterTop.Size = new System.Drawing.Size(800, 29);
            this.PanelFillterTop.TabIndex = 5;
            // 
            // PanelActionButtons
            // 
            this.PanelActionButtons.Controls.Add(this.btnViewCurrentStaff);
            this.PanelActionButtons.Controls.Add(this.btnViewExitedStaff);
            this.PanelActionButtons.Controls.Add(this.btnAddNewStaff);
            this.PanelActionButtons.Controls.Add(this.btnViewStaff);
            this.PanelActionButtons.Controls.Add(this.btnManageStaff);
            this.PanelActionButtons.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelActionButtons.Location = new System.Drawing.Point(0, 29);
            this.PanelActionButtons.Name = "PanelActionButtons";
            this.PanelActionButtons.Size = new System.Drawing.Size(800, 32);
            this.PanelActionButtons.TabIndex = 6;
            // 
            // btnViewCurrentStaff
            // 
            this.btnViewCurrentStaff.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnViewCurrentStaff.Location = new System.Drawing.Point(463, 0);
            this.btnViewCurrentStaff.Name = "btnViewCurrentStaff";
            this.btnViewCurrentStaff.Size = new System.Drawing.Size(117, 32);
            this.btnViewCurrentStaff.TabIndex = 9;
            this.btnViewCurrentStaff.Text = "View Current Staff";
            this.btnViewCurrentStaff.UseVisualStyleBackColor = true;
            this.btnViewCurrentStaff.Click += new System.EventHandler(this.btnViewCurrentStaff_Click);
            // 
            // btnDebug
            // 
            this.btnDebug.Location = new System.Drawing.Point(645, 68);
            this.btnDebug.Name = "btnDebug";
            this.btnDebug.Size = new System.Drawing.Size(152, 23);
            this.btnDebug.TabIndex = 8;
            this.btnDebug.Text = "ToggleView";
            this.btnDebug.UseVisualStyleBackColor = true;
            this.btnDebug.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnViewExitedStaff
            // 
            this.btnViewExitedStaff.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnViewExitedStaff.Location = new System.Drawing.Point(337, 0);
            this.btnViewExitedStaff.Name = "btnViewExitedStaff";
            this.btnViewExitedStaff.Size = new System.Drawing.Size(126, 32);
            this.btnViewExitedStaff.TabIndex = 7;
            this.btnViewExitedStaff.Text = "View Exited Staff";
            this.btnViewExitedStaff.UseVisualStyleBackColor = true;
            this.btnViewExitedStaff.Click += new System.EventHandler(this.btnViewExitedStaff_Click);
            // 
            // btnAddNewStaff
            // 
            this.btnAddNewStaff.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnAddNewStaff.Location = new System.Drawing.Point(225, 0);
            this.btnAddNewStaff.Name = "btnAddNewStaff";
            this.btnAddNewStaff.Size = new System.Drawing.Size(112, 32);
            this.btnAddNewStaff.TabIndex = 6;
            this.btnAddNewStaff.Text = "Add New Staff";
            this.btnAddNewStaff.UseVisualStyleBackColor = true;
            this.btnAddNewStaff.Visible = false;
            this.btnAddNewStaff.Click += new System.EventHandler(this.btnAddNewStaff_Click_1);
            // 
            // btnManageStaff
            // 
            this.btnManageStaff.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnManageStaff.Location = new System.Drawing.Point(0, 0);
            this.btnManageStaff.Name = "btnManageStaff";
            this.btnManageStaff.Size = new System.Drawing.Size(125, 32);
            this.btnManageStaff.TabIndex = 5;
            this.btnManageStaff.Text = "Manage Staff";
            this.btnManageStaff.UseVisualStyleBackColor = true;
            this.btnManageStaff.Click += new System.EventHandler(this.btnManageStaff_Click);
            // 
            // btnViewStaff
            // 
            this.btnViewStaff.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnViewStaff.Location = new System.Drawing.Point(125, 0);
            this.btnViewStaff.Name = "btnViewStaff";
            this.btnViewStaff.Size = new System.Drawing.Size(100, 32);
            this.btnViewStaff.TabIndex = 10;
            this.btnViewStaff.Text = "View Staff";
            this.btnViewStaff.UseVisualStyleBackColor = true;
            this.btnViewStaff.Visible = false;
            this.btnViewStaff.Click += new System.EventHandler(this.btnViewStaff_Click);
            // 
            // frmHR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gbEmployeeList);
            this.Controls.Add(this.PanelActions);
            this.Name = "frmHR";
            this.Text = "frmHR";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmHR_FormClosed);
            this.Load += new System.EventHandler(this.frmHR_Load);
            this.gbEmployeeList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).EndInit();
            this.PanelActions.ResumeLayout(false);
            this.PanelActionButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbEmployeeList;
        private System.Windows.Forms.DataGridView DGV;
        private System.Windows.Forms.Panel PanelActions;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGV_Title;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGV_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGV_JobTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGV_EmailAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGV_City;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGV_State;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGV_BusinessEntityID;
        private System.Windows.Forms.Panel PanelActionButtons;
        private System.Windows.Forms.Button btnViewCurrentStaff;
        private System.Windows.Forms.Button btnDebug;
        private System.Windows.Forms.Button btnViewExitedStaff;
        private System.Windows.Forms.Button btnAddNewStaff;
        private System.Windows.Forms.Button btnManageStaff;
        private System.Windows.Forms.Panel PanelFillterTop;
        private System.Windows.Forms.Button btnViewStaff;
    }
}