﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week3_Solution
{
    public partial class frmHR : Form
    {
        enum enumDisplayMode
        {
            HRManager=0, HRStaff=1, Manager=2, Staff=3
        }

        class DGVData
        {
            public int BusinessEntityID { get; set; }
            public string Title { get; set; }
            public string JobTitle { get; set; }
            public string Name { get; set; }
            public string EmailAddress { get; set; }
            public string City { get; set; }
            public string State { get; set; }
        }

        AdventureWorks2017Entities DBContext = new AdventureWorks2017Entities();
        
        enumDisplayMode CurrentDisplayMode = enumDisplayMode.Staff;
        bool DisplayCurrentStaff = true;

        public frmHR()
        {
            InitializeComponent();
        }

        private void frmHR_FormClosed(object sender, FormClosedEventArgs e)
        {
            clsGlobalVariables.LoginForm.Close();
        }

        public void RefreshDisplay() { DisplayMode(CurrentDisplayMode); }

        void DisplayMode(enumDisplayMode DisplayMode)
        {
            var theQuery = (from p in DBContext.vEmployees
                            where p.CurrentFlag == DisplayCurrentStaff
                            select p);

            CurrentDisplayMode = DisplayMode;
            switch (DisplayMode)
            {
                case enumDisplayMode.HRManager:
                    //HR Manager See ALL
                    this.Text = "Human Resource - Organization View";
                    btnAddNewStaff.Visible = DisplayCurrentStaff;
                    break;
                case enumDisplayMode.Manager:
                    //Manager - See Team
                    this.Text = "Human Resource - My Team";
                    var myTeam = DBContext.uspGetManagerEmployees(clsGlobalVariables.LoggedInUser.BusinessEntityID).Select(p => p.BusinessEntityID).ToList();
                    theQuery = (from p in theQuery
                                      where myTeam.Contains(p.BusinessEntityID)
                                      select p);
                    btnAddNewStaff.Visible = false;
                    break;
                case enumDisplayMode.Staff:
                    //Myself - See me
                    this.Text = "Human Resource - Myself";
                    theQuery = (from p in theQuery
                                where p.BusinessEntityID == clsGlobalVariables.LoggedInUser.BusinessEntityID
                                select p);
                    btnAddNewStaff.Visible = false;
                    break;
                case  enumDisplayMode.HRStaff:
                    this.Text = "Human Resource - Non management View";
                    theQuery = DBContext.Database.SqlQuery<vEmployee>(@"
select * from HumanResources.vEmployee
where 
BusinessEntityID in (
select Staff.BusinessEntityID
from HumanResources.Employee Mgr
inner join HumanResources.Employee Staff 
on Mgr.OrganizationNode = Staff.OrganizationNode.GetAncestor(1)
) and CurrentFlag=" + (DisplayCurrentStaff ? 1 : 0)).AsQueryable();
                    btnAddNewStaff.Visible = false;
                    break;
            }

            var result = (from p in theQuery
                          orderby p.FirstName, p.MiddleName, p.LastName, p.JobTitle
                              select new DGVData()
                              {
                                  BusinessEntityID = p.BusinessEntityID,
                                  Title = p.Title,
                                  JobTitle = p.JobTitle,
                                  Name = (p.FirstName + " " + p.MiddleName + " " + p.LastName).Trim(),
                                  EmailAddress = p.EmailAddress,
                                  City = p.City,
                                  State = p.StateProvinceName
                              }).ToList();

            this.Text += $" [{result.Count()}][{(DisplayCurrentStaff ? "Current" : "Exited")}]";
            DGV.DataSource = result;
            //To enable Sorting, take a look at MySortableBindingList
        }

        private void frmHR_Load(object sender, EventArgs e)
        {
            btnViewCurrentStaff.Visible = false;
            if (clsGlobalVariables.isDebug)
            {
                btnDebug.Visible = true;
            }

            if (clsGlobalVariables.LoggedInUser.GroupName == "Executive General and Administration" && clsGlobalVariables.LoggedInUser.Department == "Human Resources")
            {
                if (clsGlobalVariables.LoggedInUser.IsManager)
                {
                    //Can see all
                    DisplayMode(enumDisplayMode.HRManager);
                }
                else
                {
                    //Filter only for those that are not managing people
                    //This is the tricky one as the only way to do this is via SQL rather than linq
                    DisplayMode(enumDisplayMode.HRStaff);
                }
            }
            else
            {
                if (clsGlobalVariables.LoggedInUser.IsManager)
                {
                    //Can manage only those under them
                    DisplayMode(enumDisplayMode.Manager);
                }
                else
                {
                    //Filter only for those that are not managing people
                    DisplayMode(enumDisplayMode.Staff);
                }
            }
        }

        int DisplayID = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            var dis = (enumDisplayMode)Enum.Parse(typeof(enumDisplayMode), DisplayID.ToString());
            DisplayMode(dis);
            DisplayID++;
            if (DisplayID > 3)
                DisplayID = 0;
        }

        private void btnViewExitedStaff_Click(object sender, EventArgs e)
        {
            //Update Datagrid with exited staff only
            //hide xxx buttons
            btnViewStaff.Visible = btnViewCurrentStaff.Visible = true;
            DisplayCurrentStaff = btnManageStaff.Visible = btnViewExitedStaff.Visible = false;
            btnAddNewStaff.Visible = false;
            DisplayMode(CurrentDisplayMode);
            
        }

        private void btnViewCurrentStaff_Click(object sender, EventArgs e)
        {
            btnViewStaff.Visible = btnViewCurrentStaff.Visible = false;
            DisplayCurrentStaff = btnManageStaff.Visible = btnViewExitedStaff.Visible = true;
            btnAddNewStaff.Visible = CurrentDisplayMode == enumDisplayMode.HRManager;
            DisplayMode(CurrentDisplayMode);
        }

        private void btnViewStaff_Click(object sender, EventArgs e)
        {
            if (DGV.CurrentRow == null)
                MessageBox.Show("Please select a record");
            else
            {
                var x = (DGVData)DGV.CurrentRow.DataBoundItem;
                (new frmHRManageStaff(x.BusinessEntityID, true, this)).Show();
            }
        }

        private void btnManageStaff_Click(object sender, EventArgs e)
        {
            if (DGV.CurrentRow == null)
                MessageBox.Show("Please select a record");
            else
            {
                var x = (DGVData)DGV.CurrentRow.DataBoundItem;
                (new frmHRManageStaff(x.BusinessEntityID, false, this)).Show();
            }
        }

        private void btnAddNewStaff_Click_1(object sender, EventArgs e)
        {
            (new frmHRManageStaff(-1, false, this)).ShowDialog();
        }
    }
}
