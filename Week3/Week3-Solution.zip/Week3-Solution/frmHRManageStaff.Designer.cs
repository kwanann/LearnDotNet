﻿namespace Week3_Solution
{
    partial class frmHRManageStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStaffID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtMiddleName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.ddlGender = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnUpdateStaff = new System.Windows.Forms.Button();
            this.btnRetireStaff = new System.Windows.Forms.Button();
            this.btnUnretireStaff = new System.Windows.Forms.Button();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtAddressLine1 = new System.Windows.Forms.TextBox();
            this.txtAddressLine2 = new System.Windows.Forms.TextBox();
            this.txtAddressCity = new System.Windows.Forms.TextBox();
            this.txtAddressPostalCode = new System.Windows.Forms.TextBox();
            this.ddlMaritalStatus = new System.Windows.Forms.ComboBox();
            this.ddlDepartment = new System.Windows.Forms.ComboBox();
            this.ddlManager = new System.Windows.Forms.ComboBox();
            this.ddlPhoneNumberType = new System.Windows.Forms.ComboBox();
            this.dtpHireDate = new System.Windows.Forms.DateTimePicker();
            this.lblHireDate = new System.Windows.Forms.Label();
            this.ddlAddressState = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblStaffID
            // 
            this.lblStaffID.AutoSize = true;
            this.lblStaffID.Location = new System.Drawing.Point(26, 21);
            this.lblStaffID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblStaffID.Name = "lblStaffID";
            this.lblStaffID.Size = new System.Drawing.Size(88, 25);
            this.lblStaffID.TabIndex = 0;
            this.lblStaffID.Text = "Staff ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 88);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(170, 88);
            this.txtFirstName.Margin = new System.Windows.Forms.Padding(6);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(196, 31);
            this.txtFirstName.TabIndex = 2;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(594, 88);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(6);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(196, 31);
            this.txtLastName.TabIndex = 3;
            // 
            // txtMiddleName
            // 
            this.txtMiddleName.Location = new System.Drawing.Point(382, 88);
            this.txtMiddleName.Margin = new System.Windows.Forms.Padding(6);
            this.txtMiddleName.Name = "txtMiddleName";
            this.txtMiddleName.Size = new System.Drawing.Size(196, 31);
            this.txtMiddleName.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 160);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Date of Birth";
            // 
            // dtpDateOfBirth
            // 
            this.dtpDateOfBirth.Location = new System.Drawing.Point(170, 160);
            this.dtpDateOfBirth.Margin = new System.Windows.Forms.Padding(6);
            this.dtpDateOfBirth.Name = "dtpDateOfBirth";
            this.dtpDateOfBirth.Size = new System.Drawing.Size(532, 31);
            this.dtpDateOfBirth.TabIndex = 6;
            // 
            // ddlGender
            // 
            this.ddlGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlGender.FormattingEnabled = true;
            this.ddlGender.Location = new System.Drawing.Point(170, 219);
            this.ddlGender.Margin = new System.Windows.Forms.Padding(6);
            this.ddlGender.Name = "ddlGender";
            this.ddlGender.Size = new System.Drawing.Size(532, 33);
            this.ddlGender.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 219);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 298);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 25);
            this.label4.TabIndex = 9;
            this.label4.Text = "Marital Status";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 381);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "Department";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 444);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 25);
            this.label6.TabIndex = 11;
            this.label6.Text = "Manager";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(718, 171);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 25);
            this.label7.TabIndex = 12;
            this.label7.Text = "Phone Number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(718, 352);
            this.label8.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 25);
            this.label8.TabIndex = 13;
            this.label8.Text = "Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(718, 256);
            this.label9.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 25);
            this.label9.TabIndex = 14;
            this.label9.Text = "Email";
            // 
            // btnUpdateStaff
            // 
            this.btnUpdateStaff.Location = new System.Drawing.Point(32, 585);
            this.btnUpdateStaff.Margin = new System.Windows.Forms.Padding(6);
            this.btnUpdateStaff.Name = "btnUpdateStaff";
            this.btnUpdateStaff.Size = new System.Drawing.Size(150, 44);
            this.btnUpdateStaff.TabIndex = 15;
            this.btnUpdateStaff.Text = "Update Staff";
            this.btnUpdateStaff.UseVisualStyleBackColor = true;
            this.btnUpdateStaff.Click += new System.EventHandler(this.btnUpdateStaff_Click);
            // 
            // btnRetireStaff
            // 
            this.btnRetireStaff.Location = new System.Drawing.Point(220, 585);
            this.btnRetireStaff.Margin = new System.Windows.Forms.Padding(6);
            this.btnRetireStaff.Name = "btnRetireStaff";
            this.btnRetireStaff.Size = new System.Drawing.Size(150, 44);
            this.btnRetireStaff.TabIndex = 16;
            this.btnRetireStaff.Text = "Retire Staff";
            this.btnRetireStaff.UseVisualStyleBackColor = true;
            this.btnRetireStaff.Click += new System.EventHandler(this.btnRetireStaff_Click);
            // 
            // btnUnretireStaff
            // 
            this.btnUnretireStaff.Location = new System.Drawing.Point(420, 585);
            this.btnUnretireStaff.Margin = new System.Windows.Forms.Padding(6);
            this.btnUnretireStaff.Name = "btnUnretireStaff";
            this.btnUnretireStaff.Size = new System.Drawing.Size(238, 44);
            this.btnUnretireStaff.TabIndex = 17;
            this.btnUnretireStaff.Text = "Unretire Staff";
            this.btnUnretireStaff.UseVisualStyleBackColor = true;
            this.btnUnretireStaff.Click += new System.EventHandler(this.btnUnretireStaff_Click);
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Location = new System.Drawing.Point(1150, 165);
            this.txtPhoneNumber.Margin = new System.Windows.Forms.Padding(6);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(292, 31);
            this.txtPhoneNumber.TabIndex = 18;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(896, 250);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(6);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(546, 31);
            this.txtEmail.TabIndex = 19;
            // 
            // txtAddressLine1
            // 
            this.txtAddressLine1.Location = new System.Drawing.Point(896, 346);
            this.txtAddressLine1.Margin = new System.Windows.Forms.Padding(6);
            this.txtAddressLine1.Name = "txtAddressLine1";
            this.txtAddressLine1.Size = new System.Drawing.Size(546, 31);
            this.txtAddressLine1.TabIndex = 20;
            // 
            // txtAddressLine2
            // 
            this.txtAddressLine2.Location = new System.Drawing.Point(896, 396);
            this.txtAddressLine2.Margin = new System.Windows.Forms.Padding(6);
            this.txtAddressLine2.Name = "txtAddressLine2";
            this.txtAddressLine2.Size = new System.Drawing.Size(546, 31);
            this.txtAddressLine2.TabIndex = 21;
            // 
            // txtAddressCity
            // 
            this.txtAddressCity.Location = new System.Drawing.Point(896, 446);
            this.txtAddressCity.Margin = new System.Windows.Forms.Padding(6);
            this.txtAddressCity.Name = "txtAddressCity";
            this.txtAddressCity.Size = new System.Drawing.Size(284, 31);
            this.txtAddressCity.TabIndex = 22;
            // 
            // txtAddressPostalCode
            // 
            this.txtAddressPostalCode.Location = new System.Drawing.Point(896, 496);
            this.txtAddressPostalCode.Margin = new System.Windows.Forms.Padding(6);
            this.txtAddressPostalCode.Name = "txtAddressPostalCode";
            this.txtAddressPostalCode.Size = new System.Drawing.Size(284, 31);
            this.txtAddressPostalCode.TabIndex = 24;
            // 
            // ddlMaritalStatus
            // 
            this.ddlMaritalStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlMaritalStatus.FormattingEnabled = true;
            this.ddlMaritalStatus.Location = new System.Drawing.Point(170, 283);
            this.ddlMaritalStatus.Margin = new System.Windows.Forms.Padding(6);
            this.ddlMaritalStatus.Name = "ddlMaritalStatus";
            this.ddlMaritalStatus.Size = new System.Drawing.Size(532, 33);
            this.ddlMaritalStatus.TabIndex = 25;
            // 
            // ddlDepartment
            // 
            this.ddlDepartment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlDepartment.FormattingEnabled = true;
            this.ddlDepartment.Location = new System.Drawing.Point(170, 373);
            this.ddlDepartment.Margin = new System.Windows.Forms.Padding(6);
            this.ddlDepartment.Name = "ddlDepartment";
            this.ddlDepartment.Size = new System.Drawing.Size(532, 33);
            this.ddlDepartment.TabIndex = 26;
            // 
            // ddlManager
            // 
            this.ddlManager.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlManager.FormattingEnabled = true;
            this.ddlManager.Location = new System.Drawing.Point(170, 444);
            this.ddlManager.Margin = new System.Windows.Forms.Padding(6);
            this.ddlManager.Name = "ddlManager";
            this.ddlManager.Size = new System.Drawing.Size(532, 33);
            this.ddlManager.TabIndex = 27;
            // 
            // ddlPhoneNumberType
            // 
            this.ddlPhoneNumberType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPhoneNumberType.FormattingEnabled = true;
            this.ddlPhoneNumberType.Items.AddRange(new object[] {
            "Cell",
            "Work"});
            this.ddlPhoneNumberType.Location = new System.Drawing.Point(896, 165);
            this.ddlPhoneNumberType.Margin = new System.Windows.Forms.Padding(6);
            this.ddlPhoneNumberType.Name = "ddlPhoneNumberType";
            this.ddlPhoneNumberType.Size = new System.Drawing.Size(238, 33);
            this.ddlPhoneNumberType.TabIndex = 28;
            // 
            // dtpHireDate
            // 
            this.dtpHireDate.Location = new System.Drawing.Point(170, 513);
            this.dtpHireDate.Margin = new System.Windows.Forms.Padding(6);
            this.dtpHireDate.Name = "dtpHireDate";
            this.dtpHireDate.Size = new System.Drawing.Size(532, 31);
            this.dtpHireDate.TabIndex = 30;
            // 
            // lblHireDate
            // 
            this.lblHireDate.AutoSize = true;
            this.lblHireDate.Location = new System.Drawing.Point(26, 513);
            this.lblHireDate.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblHireDate.Name = "lblHireDate";
            this.lblHireDate.Size = new System.Drawing.Size(102, 25);
            this.lblHireDate.TabIndex = 29;
            this.lblHireDate.Text = "Hire Date";
            // 
            // ddlAddressState
            // 
            this.ddlAddressState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlAddressState.FormattingEnabled = true;
            this.ddlAddressState.Location = new System.Drawing.Point(1196, 444);
            this.ddlAddressState.Margin = new System.Windows.Forms.Padding(6);
            this.ddlAddressState.Name = "ddlAddressState";
            this.ddlAddressState.Size = new System.Drawing.Size(246, 33);
            this.ddlAddressState.TabIndex = 31;
            // 
            // frmHRManageStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1474, 658);
            this.Controls.Add(this.ddlAddressState);
            this.Controls.Add(this.dtpHireDate);
            this.Controls.Add(this.lblHireDate);
            this.Controls.Add(this.ddlPhoneNumberType);
            this.Controls.Add(this.ddlManager);
            this.Controls.Add(this.ddlDepartment);
            this.Controls.Add(this.ddlMaritalStatus);
            this.Controls.Add(this.txtAddressPostalCode);
            this.Controls.Add(this.txtAddressCity);
            this.Controls.Add(this.txtAddressLine2);
            this.Controls.Add(this.txtAddressLine1);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtPhoneNumber);
            this.Controls.Add(this.btnUnretireStaff);
            this.Controls.Add(this.btnRetireStaff);
            this.Controls.Add(this.btnUpdateStaff);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ddlGender);
            this.Controls.Add(this.dtpDateOfBirth);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtMiddleName);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblStaffID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frmHRManageStaff";
            this.Text = "+";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmHRManageStaff_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmHRManageStaff_FormClosed);
            this.Load += new System.EventHandler(this.frmHRManageStaff_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStaffID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtMiddleName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpDateOfBirth;
        private System.Windows.Forms.ComboBox ddlGender;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnUpdateStaff;
        private System.Windows.Forms.Button btnRetireStaff;
        private System.Windows.Forms.Button btnUnretireStaff;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtAddressLine1;
        private System.Windows.Forms.TextBox txtAddressLine2;
        private System.Windows.Forms.TextBox txtAddressCity;
        private System.Windows.Forms.TextBox txtAddressPostalCode;
        private System.Windows.Forms.ComboBox ddlMaritalStatus;
        private System.Windows.Forms.ComboBox ddlDepartment;
        private System.Windows.Forms.ComboBox ddlManager;
        private System.Windows.Forms.ComboBox ddlPhoneNumberType;
        private System.Windows.Forms.DateTimePicker dtpHireDate;
        private System.Windows.Forms.Label lblHireDate;
        private System.Windows.Forms.ComboBox ddlAddressState;
    }
}