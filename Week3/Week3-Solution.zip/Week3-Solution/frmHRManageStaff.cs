﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week3_Solution
{
    public partial class frmHRManageStaff : Form
    {
        class IDStringPair
        {
            public IDStringPair() { }
            public int ID { get; set; }
            public string Value { get; set; }
        }

        //-1 for new staff, otherwise id
        int BusinessEntityID { get; set; }
        bool ReadOnlyView { get; set; }
        frmHR ParentForm { get; set; }
        AdventureWorks2017Entities DBContext = new AdventureWorks2017Entities();

        public frmHRManageStaff(int businessEntityID, bool readOnlyView, frmHR parentForm)
        {
            BusinessEntityID = businessEntityID;
            ReadOnlyView = readOnlyView;
            ParentForm = parentForm;

            InitializeComponent();
        }

        private void frmHRManageStaff_Load(object sender, EventArgs e)
        {
            #region  Load all the comboboxes
            var lGender = new List<KeyValuePair<string, string>>();
            lGender.Add(new KeyValuePair<string, string>("Male", "M"));
            lGender.Add(new KeyValuePair<string, string>("Female", "F"));
            ddlGender.DataSource = lGender;
            ddlGender.DisplayMember = "Key";
            ddlGender.ValueMember = "Value";

            var lMaritalStatus = new List<KeyValuePair<string, string>>();
            lMaritalStatus.Add(new KeyValuePair<string, string>("Married", "M"));
            lMaritalStatus.Add(new KeyValuePair<string, string>("Single", "S"));
            ddlMaritalStatus.DataSource = lMaritalStatus;
            ddlMaritalStatus.DisplayMember = "Key";
            ddlMaritalStatus.ValueMember = "Value";

            ddlDepartment.DataSource = (from p in DBContext.Departments
                                        orderby p.GroupName, p.Name
                                        select new IDStringPair()
                                        {
                                            ID = p.DepartmentID,
                                            Value = p.GroupName + " - " + p.Name
                                        }).ToList();
            
            /*
            ddlDepartment.DataSource = DBContext.Departments.OrderBy(p => new { p.GroupName, p.Name }).Select(p => new IDStringPair()
            {
                ID = p.DepartmentID,
                Value = p.GroupName + " - " + p.Name
            });
            */

            ddlDepartment.DisplayMember = "Value";
            ddlDepartment.ValueMember = "ID";

            ddlManager.DataSource = (from p in DBContext.vEmployees
                                     orderby p.FirstName, p.MiddleName, p.LastName
                                     select new IDStringPair()
                                     {
                                         ID = p.BusinessEntityID,
                                         Value = (p.FirstName + " " + p.MiddleName + " " + p.LastName).Trim() + " - " + p.EmailAddress
                                     }).ToList();
            ddlManager.DisplayMember = "Value";
            ddlManager.ValueMember = "ID";

            ddlAddressState.DataSource = (from p in DBContext.StateProvinces
                                        orderby p.Name
                                        select new IDStringPair()
                                        {
                                            ID = p.StateProvinceID,
                                            Value = p.Name
                                        }).ToList();
            ddlAddressState.DisplayMember = "Value";
            ddlAddressState.ValueMember = "ID";

            ddlPhoneNumberType.DataSource = (from p in DBContext.PhoneNumberTypes
                                          orderby p.Name
                                          select new IDStringPair()
                                          {
                                              ID = p.PhoneNumberTypeID,
                                              Value = p.Name
                                          }).ToList();
            ddlPhoneNumberType.DisplayMember = "Value";
            ddlPhoneNumberType.ValueMember = "ID";
            #endregion

            if (BusinessEntityID == -1)
            {
                this.Text = "Human Resource - Add new staff";
                ReadOnlyView = false;
                lblStaffID.Text = "Staff ID: -NEW-";
                lblHireDate.Visible = dtpHireDate.Visible = true;
                dtpHireDate.Value = DateTime.Now;
                dtpDateOfBirth.Value = DateTime.Now.AddYears(-19);
                btnUpdateStaff.Text = "Add new Staff";
                btnRetireStaff.Visible = btnUnretireStaff.Visible = false;
            }
            else
            {
                lblHireDate.Visible = dtpHireDate.Visible = false;
                lblStaffID.Text = $"Staff ID: {BusinessEntityID}";
                if (ReadOnlyView)
                {
                    this.Text = "Human Resource - View Staff details";
                }
                else
                {
                    this.Text = "Human Resource - Modify Staff details";
                }

                var rec = DBContext.vEmployees.Where(p => p.BusinessEntityID == BusinessEntityID).FirstOrDefault();
                if (rec == null)
                {
                    this.Close();
                }
                else
                {
                    txtAddressCity.Text = rec.City;
                    txtAddressLine1.Text = rec.AddressLine1;
                    txtAddressLine2.Text = rec.AddressLine2;
                    txtAddressPostalCode.Text = rec.PostalCode;
                    ddlAddressState.SelectedItem = (ddlAddressState.DataSource as List<IDStringPair>).Where(p => p.Value == rec.StateProvinceName).FirstOrDefault();
                    txtEmail.Text = rec.EmailAddress;
                    txtFirstName.Text = rec.FirstName;
                    txtLastName.Text = rec.LastName;
                    txtMiddleName.Text = rec.MiddleName;
                    dtpDateOfBirth.Value = DBContext.Employees.Where(p => p.BusinessEntityID == BusinessEntityID).Select(p => p.BirthDate).FirstOrDefault();

                    //Use the tag to store existing value
                    txtPhoneNumber.Tag  = txtPhoneNumber.Text = rec.PhoneNumber;                    
                    
                    ddlGender.SelectedItem = (ddlGender.DataSource as List<KeyValuePair<string, string>>).Where(p => p.Value == rec.Gender).FirstOrDefault();
                    ddlMaritalStatus.SelectedItem = (ddlMaritalStatus.DataSource as List<KeyValuePair<string, string>>).Where(p => p.Value == rec.MaritalStatus).FirstOrDefault();
                    var theDepartment = (ddlDepartment.DataSource as List<IDStringPair>).Where(p => p.Value == DBContext.vEmployeeDepartments.Where(q => q.BusinessEntityID == rec.BusinessEntityID).Select(q => new { theDepartment = q.GroupName + " - " + q.Department }).FirstOrDefault().theDepartment).FirstOrDefault();
                    ddlDepartment.SelectedItem = theDepartment;
                    ddlDepartment.Tag = theDepartment.ID;

                    var thePhoneNumberType = (ddlPhoneNumberType.DataSource as List<IDStringPair>).Where(p => p.Value == rec.PhoneNumberType).FirstOrDefault();
                    ddlPhoneNumberType.SelectedItem = thePhoneNumberType.Value;
                    //Use the tag to store existing value
                    ddlPhoneNumberType.Tag = thePhoneNumberType.ID;

                    var theManagerID = (from p in DBContext.uspGetEmployeeManagers(rec.BusinessEntityID)
                                      orderby p.RecursionLevel descending
                                      select p.BusinessEntityID).FirstOrDefault();

                    if (theManagerID.HasValue)
                    {
                        ddlManager.SelectedItem = (ddlManager.DataSource as List<IDStringPair>).Where(p => p.ID == theManagerID).FirstOrDefault();
                    }
                    else
                    {
                        //some folks are just so high up they got no manager
                        ddlManager.DataSource = null;
                        ddlManager.Enabled = false;
                    }

                    if (ReadOnlyView)
                    {
                        btnUnretireStaff.Visible = !rec.CurrentFlag;
                        btnRetireStaff.Visible = btnUpdateStaff.Visible = false;
                    }
                    else
                    {
                        btnRetireStaff.Visible = rec.CurrentFlag;
                        btnUnretireStaff.Visible = !btnRetireStaff.Visible;
                        btnUpdateStaff.Visible = true;
                    }
                }
            }
        }

        private async void btnRetireStaff_Click(object sender, EventArgs e)
        {
            //set currentflag to 0
            var theRec = DBContext.Employees.Where(p => p.BusinessEntityID == BusinessEntityID).FirstOrDefault();
            theRec.CurrentFlag = false;
            await DBContext.SaveChangesAsync();
            MessageBox.Show("Staff is now retired from company", "Status", MessageBoxButtons.OK);
            this.Close();
        }

        private async void btnUnretireStaff_Click(object sender, EventArgs e)
        {
            //set currentflag to 1
            var theRec = DBContext.Employees.Where(p => p.BusinessEntityID == BusinessEntityID).FirstOrDefault();
            theRec.CurrentFlag = true;
            await DBContext.SaveChangesAsync();
            MessageBox.Show("Staff is now an active employee", "Status", MessageBoxButtons.OK);
            this.Close();
        }

        private async void btnUpdateStaff_Click(object sender, EventArgs e)
        {
            var dbPerson = new Person();
            var dbEmployee = new Employee();
            var dbAddress = new Address();
            var dbEmailAddress = new EmailAddress();

            var Now = DateTime.Now;

            var dbPhoneIsNew = false;
            var dbDepartmentIsNew = false;

            if (BusinessEntityID < 0)
            {
                //insert

                //Person table first
                //Get the last BusinessID
                dbPerson.BusinessEntityID = DBContext.People.OrderByDescending(p => p.BusinessEntityID).Select(p => p.BusinessEntityID).FirstOrDefault() + 1;
                dbPerson.PersonType = "EM";
                dbPerson.NameStyle = false;
                dbPerson.Title = null;
                dbPerson.EmailPromotion = 0;

                dbEmployee.BusinessEntityID = dbPerson.BusinessEntityID;
                var R = new Random();
                dbEmployee.NationalIDNumber = Guid.NewGuid().ToString().Substring(0, 12) + R.Next(101, 999).ToString();
                dbEmployee.LoginID = $"adventure-works\\{txtFirstName.Text}.{txtMiddleName.Text}.{txtLastName.Text}{R.Next(0, 99)}";

                var dbBusinessEntity = new BusinessEntity()
                {
                    BusinessEntityID = dbPerson.BusinessEntityID,
                    ModifiedDate = Now,
                    rowguid  = Guid.NewGuid()
                };

                //assumption is each is unique
                if (dbEmployee.LoginID.Length > 256)
                    dbEmployee.LoginID = dbEmployee.LoginID.Substring(0, 254) + R.Next(0, 99).ToString();
                dbEmployee.JobTitle = "";
                dbEmployee.HireDate = dtpHireDate.Value;
                dbEmployee.SalariedFlag = true;
                dbEmployee.VacationHours = 0;
                dbEmployee.SickLeaveHours = 0;
                dbEmployee.CurrentFlag = true;

                //Address
                dbAddress.AddressID = DBContext.Addresses.OrderByDescending(p => p.AddressID).Select(p => p.AddressID).FirstOrDefault() + 1;
                dbAddress.rowguid = Guid.NewGuid();

                var dbBusinessEntityAddress = new BusinessEntityAddress()
                {
                    AddressID = dbAddress.AddressID,
                    AddressTypeID = 2,
                    BusinessEntityID = dbPerson.BusinessEntityID,
                    rowguid = Guid.NewGuid()
                };

                dbEmailAddress.BusinessEntityID = dbPerson.BusinessEntityID;
                dbEmailAddress.EmailAddressID = DBContext.EmailAddresses.OrderByDescending(p => p.EmailAddressID).Select(p => p.EmailAddressID).FirstOrDefault() + 1;
                dbEmailAddress.rowguid = Guid.NewGuid();

                //Set all records to have the same rowguid.
                //Note this is not neccessary and should not be used in any way
                dbEmployee.rowguid = dbPerson.rowguid = dbBusinessEntity.rowguid;                

                DBContext.BusinessEntities.Add(dbBusinessEntity);
              
                DBContext.Employees.Add(dbEmployee);
                DBContext.People.Add(dbPerson);
                
                DBContext.Addresses.Add(dbAddress);
                DBContext.BusinessEntityAddresses.Add(dbBusinessEntityAddress);
                DBContext.EmailAddresses.Add(dbEmailAddress);

                dbPhoneIsNew = true;
                dbDepartmentIsNew = true;
            }
            else
            {
                //update
                dbPerson = DBContext.People.Where(p => p.BusinessEntityID == BusinessEntityID).FirstOrDefault();
                dbAddress = DBContext.BusinessEntityAddresses.Where(p => p.BusinessEntityID == BusinessEntityID && p.AddressTypeID == 2).Select(p => p.Address).FirstOrDefault();
                dbEmailAddress = DBContext.EmailAddresses.Where(p => p.BusinessEntityID == BusinessEntityID).FirstOrDefault();
                dbEmployee = DBContext.Employees.Where(p => p.BusinessEntityID == BusinessEntityID).FirstOrDefault();

                dbPhoneIsNew = txtPhoneNumber.Tag.ToString() != txtPhoneNumber.Text;

                if (dbPhoneIsNew)
                {
                    //Remove old phone record from system
                    //PK is composite of BusinessEntityID, PhoneNumber and PhoneNumberTtypeID
                    var oldPhoneNumberTypeID = Convert.ToInt32(ddlPhoneNumberType.Tag);
                    DBContext.PersonPhones.RemoveRange(DBContext.PersonPhones.Where(p => p.BusinessEntityID == BusinessEntityID && p.PhoneNumberTypeID == oldPhoneNumberTypeID && p.PhoneNumber == txtPhoneNumber.Tag.ToString()));
                }

                dbDepartmentIsNew = ddlDepartment.Tag.ToString() != ((IDStringPair)ddlDepartment.SelectedItem).ID.ToString();
                
                if (dbDepartmentIsNew)
                {
                    //Update existing EmployeeDepartmentHistory and set the enddate
                    var dbExistingDepartment = DBContext.EmployeeDepartmentHistories.Where(p => p.BusinessEntityID == BusinessEntityID && !p.EndDate.HasValue).FirstOrDefault();
                    if (dbExistingDepartment != null)
                    {
                        //Update the record and set an enddate
                        dbExistingDepartment.EndDate = Now;
                        dbExistingDepartment.ModifiedDate = Now;
                    }
                }
            }

            dbPerson.FirstName = txtFirstName.Text;
            dbPerson.MiddleName = txtMiddleName.Text;
            dbPerson.LastName = txtLastName.Text;
            dbPerson.ModifiedDate = Now;

            //dbEmployee.OrganizationLevel 
            dbEmployee.BirthDate = dtpDateOfBirth.Value;
            dbEmployee.MaritalStatus = ((KeyValuePair<string, string>)ddlMaritalStatus.SelectedItem).Value;
            dbEmployee.Gender = ((KeyValuePair<string, string>)ddlGender.SelectedItem).Value;
            dbEmployee.ModifiedDate = Now;

            dbAddress.AddressLine1 = txtAddressLine1.Text;
            dbAddress.AddressLine2 = txtAddressLine2.Text;
            dbAddress.City = txtAddressCity.Text;
            dbAddress.PostalCode = txtAddressPostalCode.Text;
            dbAddress.StateProvinceID = ((IDStringPair)ddlAddressState.SelectedItem).ID;
            dbAddress.ModifiedDate = Now;

            dbEmailAddress.EmailAddress1 = txtEmail.Text;
            dbEmailAddress.ModifiedDate = Now;

            if (dbPhoneIsNew)
            {
                DBContext.PersonPhones.Add(new PersonPhone() {
                    BusinessEntityID = BusinessEntityID,
                    ModifiedDate = Now,
                    PhoneNumberTypeID = ((IDStringPair)ddlPhoneNumberType.SelectedItem).ID,
                    PhoneNumber = txtPhoneNumber.Text
                });
            }

            if (dbDepartmentIsNew)
            {
                DBContext.EmployeeDepartmentHistories.Add(new EmployeeDepartmentHistory()
                {
                    BusinessEntityID = BusinessEntityID,
                    DepartmentID = Convert.ToInt16(((IDStringPair)ddlDepartment.SelectedItem).ID),
                    ModifiedDate = Now,
                    ShiftID = 1,
                    StartDate = Now
                });
            }

            await DBContext.SaveChangesAsync();
            MessageBox.Show("Changes saved", "Status", MessageBoxButtons.OK);
            this.Close();
        }

        private void frmHRManageStaff_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void frmHRManageStaff_FormClosing(object sender, FormClosingEventArgs e)
        {
            ParentForm.RefreshDisplay();
        }
    }
}
