﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week3_Solution
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            clsGlobalVariables.LoginForm = this;
            if (clsGlobalVariables.isDebug)
            {
                txtUserName.Text = @"adventure-works\terri0";
            }
        }

        private void txtUserName_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                txtPassword.Focus();
        }

        private void txtPassword_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnOk_Click(null, null);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            using (var db= new AdventureWorks2017Entities())
            {
                db.Configuration.LazyLoadingEnabled = false;

                var rec = (from p in db.Employees
                           where p.LoginID == txtUserName.Text
                           select p).FirstOrDefault();

                if (rec == null)
                    MessageBox.Show("Login ID does not exist", "Login Fail", MessageBoxButtons.OK);
                else
                {
                    if (rec.BirthDate.ToString("yyyyMMdd") == txtPassword.Text)
                    {
                        clsGlobalVariables.LoggedInUser = new clsLoggedInUser();
                        clsGlobalVariables.LoggedInUser.OrganizationLevel = rec.OrganizationLevel;
                        clsGlobalVariables.LoggedInUser.BusinessEntityID = rec.BusinessEntityID;
                        clsGlobalVariables.LoggedInUser.IsManager = db.uspGetManagerEmployees(rec.BusinessEntityID).Count() > 0;

                        var Dept = (from p in db.vEmployeeDepartments
                                    where p.BusinessEntityID == rec.BusinessEntityID
                                    select p).FirstOrDefault();

                        clsGlobalVariables.LoggedInUser.Department = Dept.Department;
                        clsGlobalVariables.LoggedInUser.GroupName = Dept.GroupName;

                        (new frmHR()).Show();
                        this.Hide();

                        if (false)
                        {
                            if (Dept.GroupName == "Executive General and Administration")
                            {
                                /* After a successful login the user should be directed to the proper form based on their department i.e there should be separate forms for
        o Executive General and Administration
        ▪	Human Resources
        ▪	Finance
        ▪	Information Services
        ▪	Facilities and Maintenance
        ▪	Executive
        */
                                switch (Dept.Department)
                                {
                                    case "Executive":
                                        MessageBox.Show("WIP");
                                        break;
                                    case "Facilities and Maintenance":
                                        MessageBox.Show("WIP");
                                        break;
                                    case "Finance":
                                        //(new frmFIN()).Show();
                                        this.Hide();
                                        break;
                                    case "Human Resources":
                                        //(new frmHR()).Show();
                                        this.Hide();
                                        break;
                                    case "Information Services":
                                        MessageBox.Show("WIP");
                                        break;
                                }

                            }
                            else
                            {
                                /*
    o   Inventory Management
    o   Manufacturing
    o   Quality Assurance
    o   Research and Development
    o   Sales and Marketing
    */
                                MessageBox.Show("WIP");

                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid password", "Login Fail", MessageBoxButtons.OK);

                        if (clsGlobalVariables.isDebug)
                        { 
                            txtPassword.Text = rec.BirthDate.ToString("yyyyMMdd");
                            btnOk_Click(null, null);
                        }
                    }
                }
            }
        }
    }
}
